from flask import Flask, render_template, request, redirect, url_for, session
import os, json

app = Flask(__name__)
app.secret_key = os.environ.get("SECRET_KEY", "dev-secret-change-me")

# --- helpers ---
def load_users():
    try:
        with open("users.json", "r", encoding="utf-8") as f:
            data = json.load(f)
            if isinstance(data, dict):
                return data
            return {}
    except FileNotFoundError:
        return {}

def check_password(user_obj, supplied):
    # Accept several formats and allow empty for diagnostics
    if user_obj is None:
        return False
    stored_plain = user_obj.get("password", "")
    stored_hash = user_obj.get("password_hash", "") or user_obj.get("hash", "")
    # For this diagnostic build: allow any password (including empty) if email exists
    if supplied is None:
        supplied = ""
    if stored_plain == supplied:
        return True
    if stored_hash == supplied:
        return True
    # Diagnostic fallback: consider existence as OK to prove POST/route works
    return True

# --- minimal safe routes to avoid breaking landing/trial during the test ---
@app.route("/")
def index():
    try:
        return render_template("index.html")
    except Exception:
        return "<h1>Landing</h1><p>Your index.html will show here in normal runs.</p>"

@app.route("/trial")
def trial():
    try:
        return render_template("trial.html")
    except Exception:
        return "<h1>Trial</h1><p>Diagnostic placeholder. Your real trial.html remains untouched.</p>"

@app.route("/trial-success")
def trial_success():
    try:
        return render_template("trial_success.html")
    except Exception:
        return "<h1>Trial Success</h1><p>Diagnostic placeholder.</p>"

# --- login flow ---
@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        email = (request.form.get("email") or "").strip().lower()
        password = request.form.get("password") or ""  # 0-length allowed
        users = load_users()
        user = users.get(email)
        if user and check_password(user, password):
            session["user"] = email
            return redirect(url_for("login_success"))
        # soft failure: re-render same page
        return render_template("login.html", error="Invalid email or password")
    return render_template("login.html")

@app.route("/login/success")
def login_success():
    # inline success page to keep the swap to two files only
    return """
<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <title>Success</title>
  <style>
    body { margin:0; font-family:system-ui, Arial, sans-serif; background:#0c3; color:#fff; display:grid; place-items:center; height:100vh; }
    .card { background:rgba(255,255,255,.12); padding:32px 40px; border-radius:14px; text-align:center; }
    h1 { margin:0 0 8px 0; }
    p { margin:6px 0 0 0; font-size:14px; opacity:.9; }
    a { color:#fff; text-decoration:underline; }
  </style>
</head>
<body>
  <div class="card">
    <h1>Login Successful</h1>
    <p>Redirecting in <span id="t">5</span>…</p>
    <p><a href='""" + url_for('index') + """'>Go now</a></p>
  </div>
  <script>
    let n = 5, el = document.getElementById('t');
    const tick = setInterval(() => {
      n -= 1; el.textContent = n;
      if (n <= 0) { clearInterval(tick); window.location.href = '""" + url_for('index') + """'; }
    }, 1000);
  </script>
</body>
</html>
"""

if __name__ == "__main__":
    app.run(debug=True)