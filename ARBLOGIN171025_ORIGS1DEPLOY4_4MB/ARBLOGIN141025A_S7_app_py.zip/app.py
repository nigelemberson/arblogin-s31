
import os
import json
import hashlib
from flask import Flask, render_template, request, redirect, url_for, session, flash

# ---- Flask setup ----
app = Flask(__name__, static_folder="static", template_folder="templates")
app.secret_key = os.environ.get("FLASK_SECRET_KEY", "dev-secret-change-me")

# Paths
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
USERS_FILE = os.path.join(BASE_DIR, "data", "users.json")

# ---- Helpers ----
def hash_password(raw: str) -> str:
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()

def load_users():
    try:
        with open(USERS_FILE, "r", encoding="utf-8") as f:
            return json.load(f) or []
    except FileNotFoundError:
        return []
    except Exception:
        return []

def get_user_by_email(email: str):
    for u in load_users():
        if u.get("email") == email:
            return u
    return None

# ---- Routes ----
@app.route("/")
def index():
    return render_template("index.html")

@app.route("/trial")
def trial():
    try:
        return render_template("free_trial.html")
    except Exception:
        return render_template("free_trial_v2.html")

@app.route("/trial-success")
def trial_success():
    try:
        return render_template("trial_success.html")
    except Exception:
        return "<h1>Trial Success</h1>"

@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "GET":
        return render_template("login.html")

    email = (request.form.get("email") or "").strip()
    password = request.form.get("password") or ""
    incoming_hash = hash_password(password)

    user = get_user_by_email(email)
    if not user or user.get("password_hash") != incoming_hash:
        flash("Invalid email or password", "error")
        return render_template("login.html"), 401

    session["user_email"] = email
    return redirect(url_for("app_page"))

@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("login"))

@app.route("/app")
def app_page():
    # Change 'app.html' below if your GUI template has a different filename
    return render_template("app.html")

if __name__ == "__main__":
    app.run(host="127.0.0.1", port=5000, debug=False)
