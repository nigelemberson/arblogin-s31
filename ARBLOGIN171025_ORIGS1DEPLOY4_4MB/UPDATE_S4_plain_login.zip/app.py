from flask import Flask, render_template, request, redirect, url_for, flash
import json
from pathlib import Path

app = Flask(__name__)
app.secret_key = "change-me-any-random-string"

BASE_DIR = Path(__file__).parent
USERS_PATH = BASE_DIR / "data" / "users.json"

# ---------- helpers ----------

def load_users():
    """Return list of user dicts. Tolerant to missing/empty file."""
    try:
        if USERS_PATH.exists():
            with USERS_PATH.open("r", encoding="utf-8") as f:
                data = json.load(f)
                if isinstance(data, list):
                    return data
    except Exception:
        pass
    return []

def find_user_by_email(email):
    email_lc = (email or "").strip().lower()
    for u in load_users():
        if (u.get("email") or "").strip().lower() == email_lc:
            return u
    return None

# ---------- routes ----------

@app.route("/")
def index():
    # Landing page
    return render_template("landing_bc.html")  # ensure this exists under templates/

@app.route("/trial", methods=["GET", "POST"])
def trial():
    # Free trial form page (display only; wire POST later if desired)
    return render_template("free_trial.html")  # ensure this exists under templates/

@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "GET":
        return render_template("login.html")  # ensure this exists under templates/

    # POST
    email = request.form.get("email", "").strip()
    pw    = request.form.get("password", "")

    user = find_user_by_email(email)
    if not user:
        flash("Invalid email or password", "error")
        return render_template("login.html"), 401

    # Plaintext password comparison (no hashes)
    if user.get("password") == pw:
        return redirect(url_for("app_page"))

    flash("Invalid email or password", "error")
    return render_template("login.html"), 401

@app.route("/app")
def app_page():
    # Your GUI template
    return render_template("app_dashboard.html")  # ensure this exists under templates/

@app.route("/logout")
def logout():
    # No server-side session yet; just bounce home
    return redirect(url_for("index"))

if __name__ == "__main__":
    app.run(debug=False)
